###### Class org.apache.http.auth.AUTH (org.apache.http.auth.AUTH)
.class public final Lorg/apache/http/auth/AUTH;
.super Ljava/lang/Object;
.source "AUTH.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final PROXY_AUTH:Ljava/lang/String;

.field public static final PROXY_AUTH_RESP:Ljava/lang/String;

.field public static final WWW_AUTH:Ljava/lang/String;

.field public static final WWW_AUTH_RESP:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "Proxy-Authenticate"

    sput-object v0, Lorg/apache/http/auth/AUTH;->PROXY_AUTH:Ljava/lang/String;

    const-string v0, "Authorization"

    sput-object v0, Lorg/apache/http/auth/AUTH;->WWW_AUTH_RESP:Ljava/lang/String;

    const-string v0, "WWW-Authenticate"

    sput-object v0, Lorg/apache/http/auth/AUTH;->WWW_AUTH:Ljava/lang/String;

    const-string v0, "Proxy-Authorization"

    sput-object v0, Lorg/apache/http/auth/AUTH;->PROXY_AUTH_RESP:Ljava/lang/String;

    return-void
.end method

.method constructor <init>()V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Ljava/lang/RuntimeException;

    const-string v1, "Stub!"

    invoke-direct {v0, v1}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw v0
.end method
