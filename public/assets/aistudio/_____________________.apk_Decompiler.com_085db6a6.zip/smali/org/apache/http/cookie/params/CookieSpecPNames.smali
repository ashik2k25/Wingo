###### Class org.apache.http.cookie.params.CookieSpecPNames (org.apache.http.cookie.params.CookieSpecPNames)
.class public interface abstract Lorg/apache/http/cookie/params/CookieSpecPNames;
.super Ljava/lang/Object;
.source "CookieSpecPNames.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final DATE_PATTERNS:Ljava/lang/String;

.field public static final SINGLE_COOKIE_HEADER:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "http.protocol.cookie-datepatterns"

    sput-object v0, Lorg/apache/http/cookie/params/CookieSpecPNames;->DATE_PATTERNS:Ljava/lang/String;

    const-string v0, "http.protocol.single-cookie-header"

    sput-object v0, Lorg/apache/http/cookie/params/CookieSpecPNames;->SINGLE_COOKIE_HEADER:Ljava/lang/String;

    return-void
.end method
