###### Class org.apache.http.conn.params.ConnConnectionPNames (org.apache.http.conn.params.ConnConnectionPNames)
.class public interface abstract Lorg/apache/http/conn/params/ConnConnectionPNames;
.super Ljava/lang/Object;
.source "ConnConnectionPNames.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final MAX_STATUS_LINE_GARBAGE:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "http.connection.max-status-line-garbage"

    sput-object v0, Lorg/apache/http/conn/params/ConnConnectionPNames;->MAX_STATUS_LINE_GARBAGE:Ljava/lang/String;

    return-void
.end method
