###### Class org.apache.http.cookie.SM (org.apache.http.cookie.SM)
.class public interface abstract Lorg/apache/http/cookie/SM;
.super Ljava/lang/Object;
.source "SM.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final COOKIE:Ljava/lang/String;

.field public static final COOKIE2:Ljava/lang/String;

.field public static final SET_COOKIE:Ljava/lang/String;

.field public static final SET_COOKIE2:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "Cookie2"

    sput-object v0, Lorg/apache/http/cookie/SM;->COOKIE2:Ljava/lang/String;

    const-string v0, "Set-Cookie2"

    sput-object v0, Lorg/apache/http/cookie/SM;->SET_COOKIE2:Ljava/lang/String;

    const-string v0, "Cookie"

    sput-object v0, Lorg/apache/http/cookie/SM;->COOKIE:Ljava/lang/String;

    const-string v0, "Set-Cookie"

    sput-object v0, Lorg/apache/http/cookie/SM;->SET_COOKIE:Ljava/lang/String;

    return-void
.end method
