###### Class org.apache.http.conn.params.ConnRoutePNames (org.apache.http.conn.params.ConnRoutePNames)
.class public interface abstract Lorg/apache/http/conn/params/ConnRoutePNames;
.super Ljava/lang/Object;
.source "ConnRoutePNames.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final DEFAULT_PROXY:Ljava/lang/String;

.field public static final FORCED_ROUTE:Ljava/lang/String;

.field public static final LOCAL_ADDRESS:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "http.route.forced-route"

    sput-object v0, Lorg/apache/http/conn/params/ConnRoutePNames;->FORCED_ROUTE:Ljava/lang/String;

    const-string v0, "http.route.default-proxy"

    sput-object v0, Lorg/apache/http/conn/params/ConnRoutePNames;->DEFAULT_PROXY:Ljava/lang/String;

    const-string v0, "http.route.local-address"

    sput-object v0, Lorg/apache/http/conn/params/ConnRoutePNames;->LOCAL_ADDRESS:Ljava/lang/String;

    return-void
.end method
