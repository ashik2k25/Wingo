###### Class org.apache.http.client.protocol.ClientContext (org.apache.http.client.protocol.ClientContext)
.class public interface abstract Lorg/apache/http/client/protocol/ClientContext;
.super Ljava/lang/Object;
.source "ClientContext.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# static fields
.field public static final AUTHSCHEME_REGISTRY:Ljava/lang/String;

.field public static final AUTH_SCHEME_PREF:Ljava/lang/String;

.field public static final COOKIESPEC_REGISTRY:Ljava/lang/String;

.field public static final COOKIE_ORIGIN:Ljava/lang/String;

.field public static final COOKIE_SPEC:Ljava/lang/String;

.field public static final COOKIE_STORE:Ljava/lang/String;

.field public static final CREDS_PROVIDER:Ljava/lang/String;

.field public static final PROXY_AUTH_STATE:Ljava/lang/String;

.field public static final TARGET_AUTH_STATE:Ljava/lang/String;

.field public static final USER_TOKEN:Ljava/lang/String;


# direct methods
.method static constructor <clinit>()V
    .registers 1

    const-string v0, "http.authscheme-registry"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->AUTHSCHEME_REGISTRY:Ljava/lang/String;

    const-string v0, "http.cookiespec-registry"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->COOKIESPEC_REGISTRY:Ljava/lang/String;

    const-string v0, "http.cookie-spec"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->COOKIE_SPEC:Ljava/lang/String;

    const-string v0, "http.user-token"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->USER_TOKEN:Ljava/lang/String;

    const-string v0, "http.cookie-store"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->COOKIE_STORE:Ljava/lang/String;

    const-string v0, "http.auth.credentials-provider"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->CREDS_PROVIDER:Ljava/lang/String;

    const-string v0, "http.auth.target-scope"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->TARGET_AUTH_STATE:Ljava/lang/String;

    const-string v0, "http.auth.scheme-pref"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->AUTH_SCHEME_PREF:Ljava/lang/String;

    const-string v0, "http.auth.proxy-scope"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->PROXY_AUTH_STATE:Ljava/lang/String;

    const-string v0, "http.cookie-origin"

    sput-object v0, Lorg/apache/http/client/protocol/ClientContext;->COOKIE_ORIGIN:Ljava/lang/String;

    return-void
.end method
