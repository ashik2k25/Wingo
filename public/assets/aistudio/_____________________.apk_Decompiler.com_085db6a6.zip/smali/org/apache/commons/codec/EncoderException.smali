###### Class org.apache.commons.codec.EncoderException (org.apache.commons.codec.EncoderException)
.class public Lorg/apache/commons/codec/EncoderException;
.super Ljava/lang/Exception;
.source "EncoderException.java"


# annotations
.annotation runtime Ljava/lang/Deprecated;
.end annotation


# direct methods
.method public constructor <init>(Ljava/lang/String;)V
    .registers 3

    invoke-direct {p0}, Ljava/lang/Exception;-><init>()V

    new-instance p1, Ljava/lang/RuntimeException;

    const-string v0, "Stub!"

    invoke-direct {p1, v0}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    throw p1
.end method
