###### Class teacher.slex.a5.ProtectedSketchApplication$MainActivity$3 (teacher.slex.a5.ProtectedSketchApplication$MainActivity$3)
.class public Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;
.super Ljava/lang/Object;

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field private final DC:Landroid/content/Context;

.field private final dEH:Ljava/lang/Throwable;

.field private final lhjf:Ljava/lang/String;


# direct methods
.method constructor <init>(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V
    .registers 4

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->DC:Landroid/content/Context;

    iput-object p2, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->dEH:Ljava/lang/Throwable;

    iput-object p3, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->lhjf:Ljava/lang/String;

    return-void
.end method

.method static EfpHkAtGB(Landroid/content/Context;Ljava/lang/Throwable;)V
    .registers 3

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->guJIliw(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V

    return-void
.end method

.method static cftwAc(Landroid/content/Context;Ljava/lang/Throwable;)V
    .registers 3

    const/4 v0, 0x0

    invoke-static {p0, p1, v0}, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->oq(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V

    return-void
.end method

.method static guJIliw(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V
    .registers 5

    invoke-static {}, Landroid/os/Looper;->getMainLooper()Landroid/os/Looper;

    move-result-object v0

    new-instance v1, Landroid/os/Handler;

    invoke-direct {v1, v0}, Landroid/os/Handler;-><init>(Landroid/os/Looper;)V

    new-instance v0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;

    invoke-direct {v0, p0, p1, p2}, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;-><init>(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V

    invoke-virtual {v1, v0}, Landroid/os/Handler;->postAtFrontOfQueue(Ljava/lang/Runnable;)Z

    return-void
.end method

.method private static je(Ljava/lang/Throwable;Ljava/lang/String;)Lteacher/slex/a5/MessageGuardException;
    .registers 4

    const/4 v0, 0x0

    new-instance v1, Lteacher/slex/a5/MessageGuardException;

    invoke-direct {v1, p0, v0}, Lteacher/slex/a5/MessageGuardException;-><init>(Ljava/lang/Throwable;Ljava/lang/String;)V

    return-object v1
.end method

.method static oq(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V
    .registers 5

    .prologue
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x23

    if-ge v0, v1, :cond_a

    invoke-static {p0, p1, p2}, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->p(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V

    goto :goto_d

    :cond_a
    invoke-static {p0, p1, p2}, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->guJIliw(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V

    :goto_d
    return-void
.end method

.method private static p(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V
    .registers 4

    invoke-static {p1, p2}, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->je(Ljava/lang/Throwable;Ljava/lang/String;)Lteacher/slex/a5/MessageGuardException;

    move-result-object v0

    throw v0
.end method

.method private static tIHslys()Ljava/lang/String;
    .registers 9

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->getMostSignificantBits()J

    move-result-wide v1

    invoke-virtual {v0}, Ljava/util/UUID;->getLeastSignificantBits()J

    move-result-wide v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    const/16 v0, 0x10

    shl-long/2addr v5, v0

    const-wide/32 v7, 0xffff

    and-long v0, v1, v7

    or-long/2addr v0, v5

    new-instance v2, Ljava/util/UUID;

    invoke-direct {v2, v0, v1, v3, v4}, Ljava/util/UUID;-><init>(JJ)V

    invoke-virtual {v2}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method


# virtual methods
.method public run()V
    .registers 4

    iget-object v0, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->DC:Landroid/content/Context;

    iget-object v1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->dEH:Ljava/lang/Throwable;

    iget-object v2, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->lhjf:Ljava/lang/String;

    invoke-static {v0, v1, v2}, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$3;->p(Landroid/content/Context;Ljava/lang/Throwable;Ljava/lang/String;)V

    return-void
.end method
