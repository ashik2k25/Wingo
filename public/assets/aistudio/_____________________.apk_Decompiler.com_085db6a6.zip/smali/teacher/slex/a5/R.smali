###### Class teacher.slex.a5.R is created by jadx
###### Class teacher.slex.a5.R.color is created by jadx
###### Class teacher.slex.a5.R.drawable is created by jadx
###### Class teacher.slex.a5.R.id is created by jadx
###### Class teacher.slex.a5.R.layout is created by jadx
###### Class teacher.slex.a5.R.mipmap is created by jadx
###### Class teacher.slex.a5.R.string is created by jadx
###### Class teacher.slex.a5.R.style is created by jadx