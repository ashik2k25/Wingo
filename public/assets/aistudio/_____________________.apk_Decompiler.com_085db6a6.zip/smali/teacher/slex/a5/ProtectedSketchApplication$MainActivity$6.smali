###### Class teacher.slex.a5.ProtectedSketchApplication$MainActivity$6 (teacher.slex.a5.ProtectedSketchApplication$MainActivity$6)
.class public final Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;
.super Ljava/lang/Object;


# static fields
.field public static final ADxI:Ljava/lang/String;

.field public static GDc:Ljava/lang/String;


# instance fields
.field public final A:Z

.field public final IEA:Z

.field public final e:Ljava/lang/String;

.field public final eotJ:I

.field public final gesq:Z

.field public final gwg:Z

.field public final hhD:Z

.field public final kHa:I

.field public final nxBu:Ljava/lang/String;

.field public final v:Z


# direct methods
.method static constructor <clinit>()V
    .registers 9

    invoke-static {}, Ljava/util/UUID;->randomUUID()Ljava/util/UUID;

    move-result-object v0

    invoke-virtual {v0}, Ljava/util/UUID;->getMostSignificantBits()J

    move-result-wide v1

    invoke-virtual {v0}, Ljava/util/UUID;->getLeastSignificantBits()J

    move-result-wide v3

    invoke-static {}, Ljava/lang/System;->currentTimeMillis()J

    move-result-wide v5

    const/16 v0, 0x10

    shl-long/2addr v5, v0

    const-wide/32 v7, 0xffff

    and-long/2addr v1, v7

    or-long/2addr v1, v5

    new-instance v0, Ljava/util/UUID;

    invoke-direct {v0, v1, v2, v3, v4}, Ljava/util/UUID;-><init>(JJ)V

    invoke-virtual {v0}, Ljava/util/UUID;->toString()Ljava/lang/String;

    move-result-object v0

    sput-object v0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->ADxI:Ljava/lang/String;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;Ljava/lang/String;I)V
    .registers 5

    .prologue
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object p1, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->ADxI:Ljava/lang/String;

    iput-object p1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->nxBu:Ljava/lang/String;

    iput-object p2, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->e:Ljava/lang/String;

    iput p3, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->kHa:I

    and-int/lit8 p1, p3, 0x1

    const/4 p2, 0x0

    const/4 v0, 0x1

    if-eqz p1, :cond_13

    const/4 p1, 0x1

    goto :goto_14

    :cond_13
    const/4 p1, 0x0

    :goto_14
    iput-boolean p1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->gwg:Z

    and-int/lit8 p1, p3, 0x2

    if-eqz p1, :cond_1c

    const/4 p1, 0x1

    goto :goto_1d

    :cond_1c
    const/4 p1, 0x0

    :goto_1d
    iput-boolean p1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->A:Z

    and-int/lit8 p1, p3, 0x4

    if-eqz p1, :cond_25

    const/4 p1, 0x1

    goto :goto_26

    :cond_25
    const/4 p1, 0x0

    :goto_26
    iput-boolean p1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->v:Z

    and-int/lit8 p1, p3, 0x8

    if-eqz p1, :cond_2e

    const/4 p1, 0x1

    goto :goto_2f

    :cond_2e
    const/4 p1, 0x0

    :goto_2f
    iput-boolean p1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->hhD:Z

    and-int/lit8 p1, p3, 0x10

    if-eqz p1, :cond_37

    const/4 p1, 0x1

    goto :goto_38

    :cond_37
    const/4 p1, 0x0

    :goto_38
    iput-boolean p1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->IEA:Z

    and-int/lit8 p1, p3, 0x20

    if-eqz p1, :cond_3f

    const/4 p2, 0x1

    :cond_3f
    iput-boolean p2, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->gesq:Z

    const/4 p1, 0x2

    iput p1, p0, Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;->eotJ:I

    return-void
.end method

.method public static native jdzffk()Lteacher/slex/a5/ProtectedSketchApplication$MainActivity$6;
.end method

.method public static spbcb(Ljava/lang/String;)V
    .registers 1

    return-void
.end method
