package org.apache.http.auth;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public final class AUTH {
    public static final String PROXY_AUTH = "Proxy-Authenticate";
    public static final String WWW_AUTH_RESP = "Authorization";
    public static final String WWW_AUTH = "WWW-Authenticate";
    public static final String PROXY_AUTH_RESP = "Proxy-Authorization";

    AUTH() {
        throw new RuntimeException("Stub!");
    }
}
