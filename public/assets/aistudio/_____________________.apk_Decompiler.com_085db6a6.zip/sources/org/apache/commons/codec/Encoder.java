package org.apache.commons.codec;

/* JADX INFO: loaded from: classes.dex */
@Deprecated
public interface Encoder {
    Object encode(Object obj) throws EncoderException;
}
